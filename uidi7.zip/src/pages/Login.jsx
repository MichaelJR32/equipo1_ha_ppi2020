import React, { Component } from 'react'
import ContainerLogin from '../components/ContainerLogin'
import NavbarLogin from '../components/NavbarLogin'

export default class Login extends Component {
  render(){
    return ( 
      <div>
        <NavbarLogin/>
        <ContainerLogin/>
      </div>
    );
    
  }
}


  
  
      


