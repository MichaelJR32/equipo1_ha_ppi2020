import React, { Component } from 'react'

export default class FooterHome extends  Component{
  render(){
    return(
      <footer class="footer mt-auto py-3">
      <div class="container">
        <span class="text"><strong>© Learning Drive 2020</strong></span>
      </div>
    </footer>
  
    );
  }
}