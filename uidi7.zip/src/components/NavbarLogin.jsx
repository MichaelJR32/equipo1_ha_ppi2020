import React, { Component } from 'react'

export default class NavbarLogin extends  Component{
  render(){
    return(
<nav class="navbar navbar-light">
  <nav class="navbar-brand">
    <img src="https://cdn4.iconfinder.com/data/icons/aiga-symbol-signs/388/aiga_taxi-256.png" width="30" height="30" class="d-inline-block align-top" alt="" loading="lazy"/>
    Learning Drive
  </nav>

</nav>
  
    );
  }
}

